"""Capacitor가 만든 안드로이드 프로젝트에 KCJ RADIO 기능을 적용"""
import os, re, shutil, glob
A = 'android/app'
SRC = f'{A}/src/main'
PKG = f'{SRC}/java/com/kcjenc/radio'

# 1) 자바 소스
os.makedirs(PKG, exist_ok=True)
for f in glob.glob('native/*.java'):
    shutil.copy(f, PKG)

# 2) 리소스(아이콘·스플래시·알림 아이콘)
for f in glob.glob('res/**/*', recursive=True):
    if os.path.isfile(f):
        dst = os.path.join(SRC, f)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(f, dst)

# 3) 매니페스트: 권한 + 서비스
m = open(f'{SRC}/AndroidManifest.xml', encoding='utf-8').read()
perms = ['RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MICROPHONE',
         'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'ACCESS_WIFI_STATE',
         'ACCESS_NETWORK_STATE', 'VIBRATE', 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS']
add = ''.join(f'    <uses-permission android:name="android.permission.{p}" />\n' for p in perms if f'permission.{p}"' not in m)
m = m.replace('</manifest>', add + '</manifest>')
svc = ('        <service android:name=".RadioService" android:exported="false"\n'
       '            android:foregroundServiceType="microphone|mediaPlayback" />\n')
if '.RadioService' not in m:
    m = m.replace('    </application>', svc + '    </application>')
m = m.replace('android:launchMode="singleTask"', 'android:launchMode="singleTask"\n            android:screenOrientation="portrait"')
open(f'{SRC}/AndroidManifest.xml', 'w', encoding='utf-8').write(m)

# 4) 서명키: GitHub Secrets(KEYSTORE_B64, KEYSTORE_PASS)에서 가져옴 — 저장소에는 키를 두지 않음
import base64, sys
kb, kp = os.environ.get('KEYSTORE_B64', '').strip(), os.environ.get('KEYSTORE_PASS', '').strip()
if not kb or not kp:
    sys.exit('서명키 Secrets(KEYSTORE_B64, KEYSTORE_PASS)가 없습니다. 저장소 Settings > Secrets and variables > Actions에 등록하세요.')
open(f'{A}/kcj-radio.keystore', 'wb').write(base64.b64decode(kb))
g = open(f'{A}/build.gradle', encoding='utf-8').read()
if 'kcj-radio.keystore' not in g:
    sign = """    signingConfigs {
        debug {
            storeFile file('kcj-radio.keystore')
            storePassword System.getenv('KEYSTORE_PASS')
            keyAlias 'kcjradio'
            keyPassword System.getenv('KEYSTORE_PASS')
        }
    }
"""
    g = g.replace('    buildTypes {', sign + '    buildTypes {', 1)
vc = os.environ.get('VERSION_CODE', '1')
g = re.sub(r'versionCode \d+', f'versionCode {vc}', g)
g = re.sub(r'versionName "[^"]*"', f'versionName "1.0.{vc}"', g)
open(f'{A}/build.gradle', 'w', encoding='utf-8').write(g)
print('patch ok, version', vc)
