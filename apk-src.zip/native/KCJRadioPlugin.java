package com.kcjenc.radio;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** 웹(무전기 화면) ↔ 안드로이드 연결 */
@CapacitorPlugin(name = "KCJRadio")
public class KCJRadioPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        MainActivity a = MainActivity.instance;
        if (a != null) a.startRadioService();
        call.resolve();
    }

    @PluginMethod
    public void headset(PluginCall call) {
        Boolean on = call.getBoolean("on", false);
        boolean v = on != null && on;
        getContext().getSharedPreferences("kcjradio", android.content.Context.MODE_PRIVATE).edit().putBoolean("headsetPtt", v).apply();
        RadioService s = RadioService.instance;
        if (s != null) s.setHeadsetPtt(v);
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        String t = call.getString("text", "수신 대기 중");
        RadioService s = RadioService.instance;
        if (s != null) s.update(t);
        call.resolve();
    }
}
