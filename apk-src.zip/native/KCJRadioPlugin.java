package com.kcjenc.radio;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** 웹(무전기 화면) ↔ 안드로이드 연결 */
@CapacitorPlugin(name = "KCJRadio")
public class KCJRadioPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        MainActivity a = MainActivity.instance;
        if (a != null) a.startRadioService();
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        String t = call.getString("text", "수신 대기 중");
        RadioService s = RadioService.instance;
        if (s != null) s.update(t);
        call.resolve();
    }
}
