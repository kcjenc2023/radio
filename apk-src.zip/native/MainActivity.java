package com.kcjenc.radio;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.KeyEvent;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.WebViewListener;
import java.util.ArrayList;

public class MainActivity extends BridgeActivity {

    static MainActivity instance;
    private boolean pttDown = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KCJRadioPlugin.class);
        super.onCreate(savedInstanceState);
        instance = this;
        setupWebView();
        setupBackButton();
        askPermissions();
    }

    /**
     * 뒤로가기: 열린 설정창 등이 있으면 닫고, 없으면 앱을 끄지 않고 바탕화면으로 보낸다(수신 대기 유지).
     * 무전기를 완전히 끄는 것은 알림의 '무전기 끄기'로만 한다.
     */
    private void setupBackButton() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    WebView w = getBridge().getWebView();
                    w.evaluateJavascript("(window.kcjBack&&window.kcjBack())?'1':'0'", v -> {
                        if (v == null || !v.contains("1")) moveTaskToBack(true);
                    });
                } catch (Exception e) {
                    moveTaskToBack(true);
                }
            }
        });
    }

    /**
     * 1) 앱이 뒤로 가도 웹뷰(무전 처리) 프로세스의 우선순위를 낮추지 않게 한다.
     *    기본값은 화면에서 안 보이면 우선순위를 낮춰 안드로이드가 얼리거나(끊김) 종료(흰 화면)시킨다.
     * 2) 그래도 웹뷰 프로세스가 종료되면 앱이 꺼지지 않고 화면을 다시 띄운다.
     */
    private void setupWebView() {
        try {
            WebView w = getBridge().getWebView();
            if (Build.VERSION.SDK_INT >= 26) {
                w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
            }
            getBridge().addWebViewListener(new WebViewListener() {
                @Override
                public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail detail) {
                    runOnUiThread(() -> recreate());
                    return true;
                }
            });
        } catch (Exception ignored) {
        }
    }

    /** 마이크·알림 권한 요청 → 배터리 최적화 제외 요청 */
    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), 77);
        } else {
            askBatteryOnce();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77) {
            askBatteryOnce();
        }
    }

    private void askBatteryOnce() {
        try {
            SharedPreferences sp = getSharedPreferences("kcjradio", MODE_PRIVATE);
            if (sp.getBoolean("batteryAsked", false)) return;
            sp.edit().putBoolean("batteryAsked", true).apply();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Exception ignored) {
        }
    }

    /** 화면이 꺼져도 수신하도록 포그라운드 서비스 시작 (무전기 전원을 켤 때 웹에서 호출) */
    public void startRadioService() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
            ContextCompat.startForegroundService(this, new Intent(this, RadioService.class));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            WebView w = getBridge().getWebView();
            if (w != null) {
                w.onResume();
                w.resumeTimers();
                w.postInvalidate();            // 돌아왔을 때 흰 화면 방지: 다시 그리기
            }
        } catch (Exception ignored) {
        }
        js("window.kcjResume&&window.kcjResume()");
    }

    @Override
    public void onPause() {
        super.onPause();
        keepTimers();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepTimers();
    }

    /** 백그라운드에서도 웹뷰 타이머가 멈추지 않게 유지 */
    private void keepTimers() {
        try {
            WebView w = getBridge().getWebView();
            if (w != null) w.resumeTimers();
        } catch (Exception ignored) {
        }
    }

    /** 볼륨(−) 버튼 = PTT. 누르는 동안 송신 */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (!pttDown && event.getRepeatCount() == 0) {
                    pttDown = true;
                    js("window.kcjPTT&&window.kcjPTT(true)");
                }
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                pttDown = false;
                js("window.kcjPTT&&window.kcjPTT(false)");
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    void js(final String code) {
        runOnUiThread(() -> {
            try {
                WebView w = getBridge().getWebView();
                if (w != null) w.evaluateJavascript(code, null);
            } catch (Exception ignored) {
            }
        });
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        try {
            stopService(new Intent(this, RadioService.class));
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
