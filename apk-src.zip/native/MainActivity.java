package com.kcjenc.radio;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.KeyEvent;
import android.webkit.WebView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.ArrayList;

public class MainActivity extends BridgeActivity {

    static MainActivity instance;
    private boolean pttDown = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KCJRadioPlugin.class);
        super.onCreate(savedInstanceState);
        instance = this;
        askPermissions();
    }

    /** 마이크·알림 권한 요청 → 배터리 최적화 제외 요청 */
    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), 77);
        } else {
            askBatteryOnce();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77) {
            askBatteryOnce();
        }
    }

    private void askBatteryOnce() {
        try {
            SharedPreferences sp = getSharedPreferences("kcjradio", MODE_PRIVATE);
            if (sp.getBoolean("batteryAsked", false)) return;
            sp.edit().putBoolean("batteryAsked", true).apply();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Exception ignored) {
        }
    }

    /** 화면이 꺼져도 수신하도록 포그라운드 서비스 시작 (무전기 전원을 켤 때 웹에서 호출) */
    public void startRadioService() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
            ContextCompat.startForegroundService(this, new Intent(this, RadioService.class));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        keepWebViewRunning();
    }

    @Override
    public void onPause() {
        super.onPause();
        keepWebViewRunning();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepWebViewRunning();
    }

    /** 백그라운드에서도 웹뷰(무전 처리)가 멈추지 않게 유지 */
    private void keepWebViewRunning() {
        try {
            WebView w = getBridge().getWebView();
            if (w != null) {
                w.onResume();
                w.resumeTimers();
            }
        } catch (Exception ignored) {
        }
    }

    /** 볼륨(−) 버튼 = PTT. 누르는 동안 송신 */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (!pttDown && event.getRepeatCount() == 0) {
                    pttDown = true;
                    js("window.kcjPTT&&window.kcjPTT(true)");
                }
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                pttDown = false;
                js("window.kcjPTT&&window.kcjPTT(false)");
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    void js(final String code) {
        runOnUiThread(() -> {
            try {
                WebView w = getBridge().getWebView();
                if (w != null) w.evaluateJavascript(code, null);
            } catch (Exception ignored) {
            }
        });
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        try {
            stopService(new Intent(this, RadioService.class));
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
